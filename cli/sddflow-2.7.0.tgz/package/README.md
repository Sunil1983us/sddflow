# sddflow — SDD Framework CLI (Node.js)

> **Maintenance mode.** This Node.js CLI covers scaffolding only
> (`sdd init` / `sdd upgrade`) and receives fixes, not new features.
> New capabilities land in the **Python CLI** (`pip install sddflow`) —
> Jira, Confluence, review gates, PR automation. If you install both,
> they collide on the `sdd` binary name: prefer the Python CLI.

Cross-platform replacement for `setup.sh` / `setup.ps1`.  
No bash required. Works on Mac, Linux, and Windows.

## Install

> ⚠️ The `sdd-init` name on npm belongs to an **unrelated third-party
> package** — do not install it. This CLI ships from source only:

```bash
git clone https://github.com/Sunil1983us/Universalguide
npm install -g ./Universalguide/cli
sdd init
```

**Alternative:** use `bash setup.sh` (Mac/Linux) or `.\setup.ps1` (Windows) instead —
they do exactly the same thing as `sdd init` without needing Node.js or npm.

For development / contributors:

```bash
git clone https://github.com/sunil1983us/universalguide.git
cd universalguide/cli
npm install
node bin/sdd.js init
```

## Commands

### `sdd init`

Initialize an SDD pack in the current project directory.  
Replaces `bash setup.sh` / `.\setup.ps1`.

```bash
# Interactive (recommended)
sdd init

# Non-interactive
sdd init --project "my-payments-api" \
         --feature "user-authentication" \
         --scope   pilot \
         --type    backend-service
```

**Options:**

| Flag | Description | Default |
|---|---|---|
| `-p, --project <name>` | Project name | prompted |
| `-f, --feature <name>` | First feature name | prompted |
| `-s, --scope <scope>` | `pilot` \| `mvp` \| `full` | `pilot` |
| `-t, --type <type>` | Project type (auto-detected if omitted) | auto |

**What it does:**
1. Auto-detects project type from files in the current directory
2. Updates `.specify/manifest.yml` using `js-yaml` — no injection risk
3. Creates `.specify/contexts/{feature}.md` (template)
4. Creates `.specify/features/{feature}/` output directory

**Why this is safer than `setup.sh`:**  
`manifest.yml` is written by `js-yaml.dump()` — project/feature names with special characters (`'`, `\`, `&`, etc.) are serialized as YAML data, never as code. The only rejected character is `"` (which would produce invalid YAML regardless of approach).

---

### `sdd upgrade`

Migrate an existing project's `manifest.yml` to the current pack version.

```bash
sdd upgrade
```

Shows what changed between your current `sdd_version` and the CLI version,
applies the migration to `manifest.yml`, and updates `sdd_version`.

---

## Supported Project Types

| Type | Detected from |
|---|---|
| `backend-service` | `pom.xml`, `build.gradle`, `go.mod`, Python files |
| `frontend-spa` | `package.json` + react/vue/svelte/angular/next/nuxt |
| `mobile` | `pubspec.yaml`, or `package.json` + react-native/expo |
| `fullstack` | `package.json` + `pom.xml`/`build.gradle`/`go.mod` |
| `cli` | `Cargo.toml` with `[[bin]]`, or `go.mod` + `cmd/` dir |
| `data-ml` | `requirements.txt` with pandas/torch/sklearn/keras/jax |
| `serverless` | `serverless.yml`, or `template.yaml` with AWSTemplateFormatVersion |
| `library` | `Cargo.toml` without `[[bin]]`, or Python lib structure |
| `iac` | `*.tf` files, `Pulumi.yaml`, `cdk.json` |
| `desktop` | `package.json` + electron, or `tauri.conf.json` |

Detection order matches `setup.sh` and `specify.prompt.md` Step 0.

---

## Requirements

- Node.js ≥ 18
- An SDD pack already copied into your project directory
